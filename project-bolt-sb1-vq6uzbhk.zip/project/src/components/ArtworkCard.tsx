import { Heart, Eye } from 'lucide-react';
import { Artwork } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';

type ArtworkCardProps = {
  artwork: Artwork;
  onLike?: (artworkId: string) => void;
  isLiked?: boolean;
  showStats?: boolean;
};

export const ArtworkCard = ({ artwork, onLike, isLiked = false, showStats = true }: ArtworkCardProps) => {
  const navigate = useNavigate();

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    onLike?.(artwork.id);
  };

  return (
    <div
      onClick={() => navigate(`/artwork/${artwork.id}`)}
      className="bg-white rounded-lg shadow-md overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-xl"
    >
      <div className="relative">
        <img
          src={artwork.image_url}
          alt={artwork.title}
          className="w-full h-64 object-cover"
        />
        {onLike && (
          <button
            onClick={handleLike}
            className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm p-2 rounded-full shadow-lg hover:bg-white transition-all"
          >
            <Heart
              className={`w-5 h-5 ${isLiked ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
            />
          </button>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg text-gray-900 mb-1 line-clamp-1">{artwork.title}</h3>
        <p className="text-sm text-gray-600 mb-2">{artwork.category}</p>
        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-gray-900">₹{artwork.price}</span>
          {showStats && (
            <div className="flex items-center gap-3 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Heart className="w-4 h-4" />
                <span>{artwork.likes_count}</span>
              </div>
              <div className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                <span>{artwork.views_count}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
