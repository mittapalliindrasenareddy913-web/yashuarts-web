import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Artwork = {
  id: string;
  title: string;
  description: string;
  category: 'Pencil Sketch' | 'Color Portrait' | 'Couple Sketch' | 'Custom Drawing';
  price: number;
  image_url: string;
  is_featured: boolean;
  likes_count: number;
  views_count: number;
  created_at: string;
};

export type Order = {
  id: string;
  user_id: string;
  customer_name: string;
  customer_phone: string;
  artwork_type: 'Pencil Sketch' | 'Color Portrait' | 'Couple Portrait';
  reference_image_url: string;
  special_instructions: string;
  amount: number;
  payment_status: 'pending' | 'paid';
  payment_method: 'UPI' | 'Cash' | 'Online';
  order_status: 'Pending' | 'In Progress' | 'Completed' | 'Delivered';
  created_at: string;
};

export type Message = {
  id: string;
  sender_id: string;
  recipient_id: string;
  message: string;
  created_at: string;
};

export type Review = {
  id: string;
  artwork_id: string;
  user_id: string;
  rating: number;
  comment: string;
  created_at: string;
};

export type UserProfile = {
  id: string;
  full_name: string;
  avatar_url: string;
  created_at: string;
  updated_at: string;
};
