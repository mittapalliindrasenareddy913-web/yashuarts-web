import { useState, useEffect } from 'react';
import { Search, Filter, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase, Artwork } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { ArtworkCard } from '../components/ArtworkCard';
import { LoadingSpinner } from '../components/LoadingSpinner';

const categories = ['All', 'Pencil Sketch', 'Color Portrait', 'Couple Sketch', 'Custom Drawing'];

export const GalleryScreen = () => {
  const [artworks, setArtworks] = useState<Artwork[]>([]);
  const [filteredArtworks, setFilteredArtworks] = useState<Artwork[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [likedArtworks, setLikedArtworks] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    loadArtworks();
    subscribeToChanges();
  }, [user]);

  useEffect(() => {
    filterArtworks();
  }, [artworks, selectedCategory, searchQuery]);

  const loadArtworks = async () => {
    const [artworksRes, likesRes] = await Promise.all([
      supabase.from('artworks').select('*').order('created_at', { ascending: false }),
      user ? supabase.from('user_likes').select('artwork_id').eq('user_id', user.id) : { data: [] },
    ]);

    setArtworks(artworksRes.data || []);
    setLikedArtworks(new Set(likesRes.data?.map((l: any) => l.artwork_id) || []));
    setLoading(false);
  };

  const subscribeToChanges = () => {
    const channel = supabase
      .channel('gallery_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'artworks' }, () => {
        loadArtworks();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const filterArtworks = () => {
    let filtered = artworks;

    if (selectedCategory !== 'All') {
      filtered = filtered.filter((art) => art.category === selectedCategory);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (art) =>
          art.title.toLowerCase().includes(query) ||
          art.category.toLowerCase().includes(query) ||
          art.description?.toLowerCase().includes(query)
      );
    }

    setFilteredArtworks(filtered);
  };

  const handleLike = async (artworkId: string) => {
    if (!user) {
      navigate('/login');
      return;
    }

    const isLiked = likedArtworks.has(artworkId);
    const newLikedArtworks = new Set(likedArtworks);

    if (isLiked) {
      newLikedArtworks.delete(artworkId);
      await supabase.from('user_likes').delete().match({ user_id: user.id, artwork_id: artworkId });
      await supabase.rpc('decrement_likes', { artwork_id: artworkId });
    } else {
      newLikedArtworks.add(artworkId);
      await supabase.from('user_likes').insert({ user_id: user.id, artwork_id: artworkId });
      await supabase.rpc('increment_likes', { artwork_id: artworkId });
    }

    setLikedArtworks(newLikedArtworks);
    loadArtworks();
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <button onClick={() => navigate('/')} className="text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Gallery</h1>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowSearch(!showSearch)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <Search className="w-5 h-5 text-gray-600" />
              </button>
              <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <Filter className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>

          {showSearch && (
            <div className="mb-4">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search artworks..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
            </div>
          )}

          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full font-medium whitespace-nowrap transition-all ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-md'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {filteredArtworks.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No artworks found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArtworks.map((artwork) => (
              <ArtworkCard
                key={artwork.id}
                artwork={artwork}
                onLike={handleLike}
                isLiked={likedArtworks.has(artwork.id)}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};
