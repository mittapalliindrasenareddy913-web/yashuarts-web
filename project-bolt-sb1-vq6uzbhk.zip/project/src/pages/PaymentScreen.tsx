import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { CheckCircle, Phone, Shield, ArrowLeft } from 'lucide-react';
import { supabase, Order } from '../lib/supabase';

const ARTIST_UPI = 'yashuarts@paytm';
const ARTIST_PHONE = '+919876543210';

export const PaymentScreen = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const order = location.state?.order as Order;
  const [showQR, setShowQR] = useState(false);
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const [loading, setLoading] = useState(false);

  if (!order) {
    navigate('/');
    return null;
  }

  const upiUrl = `upi://pay?pa=${ARTIST_UPI}&pn=YashuArts&am=${order.amount}&cu=INR&tn=Order${order.id.slice(0, 8)}`;

  const handleUPIPay = () => {
    window.location.href = upiUrl;
  };

  const handleWhatsAppPay = () => {
    const message = encodeURIComponent(
      `Hi! I want to make payment of ₹${order.amount} for Order #${order.id.slice(0, 8)}. Please share payment details.`
    );
    window.open(`https://wa.me/${ARTIST_PHONE.replace('+', '')}?text=${message}`, '_blank');
  };

  const handleConfirmPayment = async () => {
    setLoading(true);

    const { error } = await supabase
      .from('orders')
      .update({ payment_status: 'paid', payment_method: 'UPI' })
      .eq('id', order.id);

    if (!error) {
      setPaymentConfirmed(true);
    }

    setLoading(false);
  };

  if (paymentConfirmed) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="bg-green-100 p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Payment Confirmed!</h2>
          <p className="text-gray-600 mb-6">Thank you for your order</p>

          <div className="bg-gray-50 rounded-lg p-4 mb-6 text-left">
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">Order ID:</span>
              <span className="font-semibold text-gray-900">#{order.id.slice(0, 8)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Amount Paid:</span>
              <span className="font-semibold text-green-600 text-lg">₹{order.amount}</span>
            </div>
          </div>

          <p className="text-sm text-gray-600 mb-6">
            We'll start working on your artwork right away. You'll receive updates on WhatsApp.
          </p>

          <button
            onClick={() => navigate('/')}
            className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white py-3 rounded-lg font-semibold hover:from-amber-600 hover:to-orange-700 transition-all"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-900">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Payment</h1>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Order Summary</h2>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-600">Order ID</p>
                <p className="font-semibold text-gray-900">#{order.id.slice(0, 8)}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">Amount</p>
                <p className="text-3xl font-bold text-amber-600">₹{order.amount}</p>
              </div>
            </div>
          </div>
          <div className="text-sm text-gray-600">
            <p><strong>Artwork Type:</strong> {order.artwork_type}</p>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Choose Payment Method</h2>

          <div className="space-y-3">
            <button
              onClick={handleUPIPay}
              className="w-full flex items-center justify-between p-4 border-2 border-gray-200 rounded-lg hover:border-amber-400 hover:bg-amber-50 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="bg-amber-100 p-2 rounded-lg">
                  <svg className="w-6 h-6 text-amber-600" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z" />
                  </svg>
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-900">UPI Smart Pay</div>
                  <div className="text-sm text-gray-600">GPay, PhonePe, Paytm</div>
                </div>
              </div>
              <span className="text-amber-600 font-semibold">Pay Now</span>
            </button>

            <button
              onClick={handleWhatsAppPay}
              className="w-full flex items-center justify-between p-4 border-2 border-gray-200 rounded-lg hover:border-green-400 hover:bg-green-50 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="bg-green-100 p-2 rounded-lg">
                  <svg className="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
                  </svg>
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-900">WhatsApp Pay</div>
                  <div className="text-sm text-gray-600">Chat with artist</div>
                </div>
              </div>
              <span className="text-green-600 font-semibold">Contact</span>
            </button>

            <button
              onClick={() => setShowQR(!showQR)}
              className="w-full flex items-center justify-between p-4 border-2 border-gray-200 rounded-lg hover:border-blue-400 hover:bg-blue-50 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" />
                  </svg>
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-900">Scan QR Code</div>
                  <div className="text-sm text-gray-600">Any UPI app</div>
                </div>
              </div>
              <span className="text-blue-600 font-semibold">{showQR ? 'Hide' : 'Show'}</span>
            </button>
          </div>

          {showQR && (
            <div className="mt-6 p-6 bg-gray-50 rounded-lg text-center">
              <QRCodeSVG value={upiUrl} size={200} className="mx-auto mb-4" />
              <p className="text-sm text-gray-600">Scan with any UPI app to pay</p>
            </div>
          )}
        </div>

        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white mb-6">
          <div className="flex items-center gap-3 mb-3">
            <Shield className="w-6 h-6" />
            <h3 className="font-semibold text-lg">Secure Payment</h3>
          </div>
          <p className="text-blue-100 text-sm">
            All payments are end-to-end encrypted. Your financial data is completely safe.
          </p>
        </div>

        <button
          onClick={handleConfirmPayment}
          disabled={loading}
          className="w-full bg-green-600 text-white py-4 rounded-xl font-semibold hover:bg-green-700 transition-all disabled:opacity-50 shadow-md mb-4"
        >
          {loading ? 'Confirming...' : 'I have Paid'}
        </button>

        <div className="text-center">
          <a
            href={`tel:${ARTIST_PHONE}`}
            className="inline-flex items-center gap-2 text-amber-600 hover:text-amber-700 font-medium"
          >
            <Phone className="w-4 h-4" />
            Need help? Call support
          </a>
        </div>
      </main>
    </div>
  );
};
