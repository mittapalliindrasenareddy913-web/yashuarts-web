import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trophy, Upload, Image, CircleUser as UserCircle, LogOut, Palette } from 'lucide-react';
import { supabase, Artwork } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { ArtworkCard } from '../components/ArtworkCard';
import { LoadingSpinner } from '../components/LoadingSpinner';

export const HomeScreen = () => {
  const [featuredArtwork, setFeaturedArtwork] = useState<Artwork | null>(null);
  const [trendingArtworks, setTrendingArtworks] = useState<Artwork[]>([]);
  const [masterpieces, setMasterpieces] = useState<Artwork[]>([]);
  const [newArrivals, setNewArrivals] = useState<Artwork[]>([]);
  const [likedArtworks, setLikedArtworks] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
    subscribeToChanges();
  }, [user]);

  const loadData = async () => {
    const [featuredRes, trendingRes, masterpiecesRes, newArrivalsRes, likesRes] = await Promise.all([
      supabase.from('artworks').select('*').eq('is_featured', true).limit(1).maybeSingle(),
      supabase.from('artworks').select('*').order('likes_count', { ascending: false }).limit(10),
      supabase.from('artworks').select('*').order('created_at', { ascending: false }).limit(6),
      supabase.from('artworks').select('*').order('created_at', { ascending: false }).limit(20),
      user ? supabase.from('user_likes').select('artwork_id').eq('user_id', user.id) : { data: [] },
    ]);

    setFeaturedArtwork(featuredRes.data);
    setTrendingArtworks(trendingRes.data || []);
    setMasterpieces(masterpiecesRes.data || []);
    setNewArrivals(newArrivalsRes.data || []);
    setLikedArtworks(new Set(likesRes.data?.map((l: any) => l.artwork_id) || []));
    setLoading(false);
  };

  const subscribeToChanges = () => {
    const channel = supabase
      .channel('artworks_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'artworks' }, () => {
        loadData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleLike = async (artworkId: string) => {
    if (!user) {
      navigate('/login');
      return;
    }

    const isLiked = likedArtworks.has(artworkId);
    const newLikedArtworks = new Set(likedArtworks);

    if (isLiked) {
      newLikedArtworks.delete(artworkId);
      await supabase.from('user_likes').delete().match({ user_id: user.id, artwork_id: artworkId });
      await supabase.rpc('decrement_likes', { artwork_id: artworkId });
    } else {
      newLikedArtworks.add(artworkId);
      await supabase.from('user_likes').insert({ user_id: user.id, artwork_id: artworkId });
      await supabase.rpc('increment_likes', { artwork_id: artworkId });
    }

    setLikedArtworks(newLikedArtworks);
    loadData();
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/login');
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-amber-500 to-orange-600 p-2 rounded-lg">
              <Palette className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">YashuArts</h1>
              <p className="text-xs text-gray-600">Visionary Art Studio</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-sm font-medium">Logout</span>
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {featuredArtwork && (
          <section className="mb-12">
            <div className="relative bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl overflow-hidden shadow-2xl">
              <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full flex items-center gap-2 shadow-lg">
                <Trophy className="w-5 h-5 text-amber-600" />
                <span className="font-semibold text-gray-900">Artwork of the Day</span>
              </div>
              <div className="grid md:grid-cols-2 gap-8 p-8">
                <div className="flex items-center justify-center">
                  <img
                    src={featuredArtwork.image_url}
                    alt={featuredArtwork.title}
                    className="rounded-xl shadow-2xl max-h-96 object-cover cursor-pointer"
                    onClick={() => navigate(`/artwork/${featuredArtwork.id}`)}
                  />
                </div>
                <div className="flex flex-col justify-center text-white">
                  <h2 className="text-4xl font-bold mb-4">{featuredArtwork.title}</h2>
                  <p className="text-lg mb-6 opacity-90">{featuredArtwork.description}</p>
                  <div className="flex items-center gap-4 mb-6">
                    <span className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
                      {featuredArtwork.category}
                    </span>
                    <span className="text-2xl font-bold">₹{featuredArtwork.price}</span>
                  </div>
                  <button
                    onClick={() => navigate(`/artwork/${featuredArtwork.id}`)}
                    className="bg-white text-amber-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-all w-fit shadow-lg"
                  >
                    View Details
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        <section className="mb-12">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-8 text-white shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold mb-2">Want Custom Artwork?</h3>
                <p className="text-blue-100">Upload your photo and get a beautiful portrait</p>
              </div>
              <button
                onClick={() => navigate('/custom-order')}
                className="bg-white text-blue-600 px-6 py-3 rounded-full font-semibold hover:bg-blue-50 transition-all flex items-center gap-2 shadow-lg"
              >
                <Upload className="w-5 h-5" />
                Upload Photo Now
              </button>
            </div>
          </div>
        </section>

        {trendingArtworks.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Trending Now</h2>
            <div className="overflow-x-auto pb-4">
              <div className="flex gap-4 min-w-max">
                {trendingArtworks.map((artwork) => (
                  <div key={artwork.id} className="w-80 flex-shrink-0">
                    <ArtworkCard
                      artwork={artwork}
                      onLike={handleLike}
                      isLiked={likedArtworks.has(artwork.id)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {masterpieces.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Masterpieces</h2>
            <div className="overflow-x-auto pb-4">
              <div className="flex gap-4 min-w-max">
                {masterpieces.map((artwork) => (
                  <div key={artwork.id} className="w-80 flex-shrink-0">
                    <ArtworkCard
                      artwork={artwork}
                      onLike={handleLike}
                      isLiked={likedArtworks.has(artwork.id)}
                    />
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {newArrivals.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">New Arrivals</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {newArrivals.slice(0, 9).map((artwork) => (
                <ArtworkCard
                  key={artwork.id}
                  artwork={artwork}
                  onLike={handleLike}
                  isLiked={likedArtworks.has(artwork.id)}
                />
              ))}
            </div>
          </section>
        )}

        <section className="mb-12">
          <div className="grid md:grid-cols-2 gap-4">
            <button
              onClick={() => navigate('/gallery')}
              className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center gap-4 border-2 border-gray-100 hover:border-amber-200"
            >
              <div className="bg-amber-100 p-4 rounded-lg">
                <Image className="w-8 h-8 text-amber-600" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-lg text-gray-900">Browse Gallery</h3>
                <p className="text-sm text-gray-600">Explore all artworks</p>
              </div>
            </button>
            <button
              onClick={() => navigate('/artist')}
              className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center gap-4 border-2 border-gray-100 hover:border-amber-200"
            >
              <div className="bg-orange-100 p-4 rounded-lg">
                <UserCircle className="w-8 h-8 text-orange-600" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-lg text-gray-900">Artist Profile</h3>
                <p className="text-sm text-gray-600">Meet the artist</p>
              </div>
            </button>
          </div>
        </section>
      </main>
    </div>
  );
};
