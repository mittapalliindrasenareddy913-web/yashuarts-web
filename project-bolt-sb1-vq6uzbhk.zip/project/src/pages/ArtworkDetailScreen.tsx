import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Heart, Share2, Eye, ArrowLeft, MessageCircle, ShoppingCart, Star } from 'lucide-react';
import { supabase, Artwork, Review } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { LoadingSpinner } from '../components/LoadingSpinner';

const orderStatusColors = {
  Pending: 'bg-yellow-100 text-yellow-800',
  'In Progress': 'bg-blue-100 text-blue-800',
  Completed: 'bg-green-100 text-green-800',
  Delivered: 'bg-gray-100 text-gray-800',
};

export const ArtworkDetailScreen = () => {
  const { id } = useParams<{ id: string }>();
  const [artwork, setArtwork] = useState<Artwork | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLiked, setIsLiked] = useState(false);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      loadArtwork();
      incrementViews();
    }
  }, [id, user]);

  const loadArtwork = async () => {
    const [artworkRes, reviewsRes, likeRes] = await Promise.all([
      supabase.from('artworks').select('*').eq('id', id).maybeSingle(),
      supabase.from('reviews').select('*').eq('artwork_id', id).order('created_at', { ascending: false }),
      user ? supabase.from('user_likes').select('*').match({ user_id: user.id, artwork_id: id }).maybeSingle() : { data: null },
    ]);

    setArtwork(artworkRes.data);
    setReviews(reviewsRes.data || []);
    setIsLiked(!!likeRes.data);
    setLoading(false);
  };

  const incrementViews = async () => {
    if (id) {
      await supabase.from('artworks').update({ views_count: (artwork?.views_count || 0) + 1 }).eq('id', id);
    }
  };

  const handleLike = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (isLiked) {
      await supabase.from('user_likes').delete().match({ user_id: user.id, artwork_id: id });
      await supabase.rpc('decrement_likes', { artwork_id: id });
    } else {
      await supabase.from('user_likes').insert({ user_id: user.id, artwork_id: id });
      await supabase.rpc('increment_likes', { artwork_id: id });
    }

    setIsLiked(!isLiked);
    loadArtwork();
  };

  const handleShare = async () => {
    if (navigator.share && artwork) {
      try {
        await navigator.share({
          title: artwork.title,
          text: `Check out this amazing artwork: ${artwork.title}`,
          url: window.location.href,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!artwork) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-500">Artwork not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="text-gray-600 hover:text-gray-900">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">Artwork Details</h1>
          <div className="w-6"></div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6 animate-fade-in">
          <div className="relative">
            <div className="h-[450px] bg-gray-100 flex items-center justify-center">
              <img
                src={artwork.image_url}
                alt={artwork.title}
                className="max-h-full max-w-full object-contain"
              />
            </div>
            <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-sm text-white px-3 py-1 rounded-full text-sm font-medium">
              YashuArts © PRO PROTECTED
            </div>
          </div>

          <div className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">{artwork.title}</h2>
                <span className="inline-block bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium">
                  {artwork.category}
                </span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleLike}
                  className="p-3 bg-white border-2 border-gray-200 rounded-full hover:border-red-300 transition-all shadow-sm"
                >
                  <Heart className={`w-6 h-6 ${isLiked ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
                </button>
                <button
                  onClick={handleShare}
                  className="p-3 bg-white border-2 border-gray-200 rounded-full hover:border-blue-300 transition-all shadow-sm"
                >
                  <Share2 className="w-6 h-6 text-gray-600" />
                </button>
              </div>
            </div>

            <div className="flex items-center gap-6 mb-6 text-gray-600">
              <div className="flex items-center gap-2">
                <Heart className="w-5 h-5" />
                <span className="font-semibold">{artwork.likes_count}</span>
                <span className="text-sm">Likes</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                <span className="font-semibold">{artwork.views_count}</span>
                <span className="text-sm">Views</span>
              </div>
            </div>

            <div className="mb-6">
              <span className="text-4xl font-bold text-gray-900">₹{artwork.price}</span>
            </div>

            {artwork.description && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">The Vision</h3>
                <p className="text-gray-700 leading-relaxed">{artwork.description}</p>
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-semibold text-gray-600 mb-1">Medium</h4>
                <p className="text-gray-900">{artwork.category}</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-semibold text-gray-600 mb-1">Artist</h4>
                <p className="text-gray-900">YashuArts Studio</p>
              </div>
            </div>

            {reviews.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Customer Reviews</h3>
                <div className="space-y-4">
                  {reviews.slice(0, 3).map((review) => (
                    <div key={review.id} className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-gray-600">
                          {new Date(review.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-gray-700">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <button
            onClick={() => navigate('/chat')}
            className="flex items-center justify-center gap-3 bg-white border-2 border-gray-200 text-gray-900 py-4 rounded-xl font-semibold hover:border-amber-400 hover:bg-amber-50 transition-all shadow-sm"
          >
            <MessageCircle className="w-5 h-5" />
            Chat with Artist
          </button>
          <button
            onClick={() => navigate('/custom-order')}
            className="flex items-center justify-center gap-3 bg-gradient-to-r from-amber-500 to-orange-600 text-white py-4 rounded-xl font-semibold hover:from-amber-600 hover:to-orange-700 transition-all shadow-md"
          >
            <ShoppingCart className="w-5 h-5" />
            Order Custom
          </button>
        </div>
      </main>
    </div>
  );
};
