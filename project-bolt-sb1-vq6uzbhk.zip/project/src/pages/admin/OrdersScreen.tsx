import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, RefreshCw, Trash2, X } from 'lucide-react';
import { supabase, Order } from '../../lib/supabase';
import { LoadingSpinner } from '../../components/LoadingSpinner';

const orderStatuses = ['Pending', 'In Progress', 'Completed', 'Delivered'];
const paymentMethods = ['UPI', 'Cash', 'Online'];

export const OrdersScreen = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    const { data } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false });

    setOrders(data || []);
    setLoading(false);
  };

  const updateOrderStatus = async (orderId: string, currentStatus: string) => {
    const currentIndex = orderStatuses.indexOf(currentStatus);
    const nextStatus = orderStatuses[(currentIndex + 1) % orderStatuses.length];

    await supabase
      .from('orders')
      .update({ order_status: nextStatus })
      .eq('id', orderId);

    loadOrders();
  };

  const updatePaymentStatus = async (orderId: string) => {
    await supabase
      .from('orders')
      .update({ payment_status: 'paid' })
      .eq('id', orderId);

    loadOrders();
  };

  const updatePaymentMethod = async (orderId: string, method: string) => {
    await supabase
      .from('orders')
      .update({ payment_method: method })
      .eq('id', orderId);

    loadOrders();
  };

  const handleDelete = async (id: string, imageUrl: string) => {
    if (deleteConfirm !== id) {
      setDeleteConfirm(id);
      setTimeout(() => setDeleteConfirm(null), 3000);
      return;
    }

    try {
      const fileName = imageUrl.split('/').pop();
      if (fileName) {
        await supabase.storage.from('orders').remove([fileName]);
      }
    } catch (error) {
      console.error('Error deleting image:', error);
    }

    await supabase.from('orders').delete().eq('id', id);
    setDeleteConfirm(null);
    loadOrders();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'In Progress':
        return 'bg-blue-100 text-blue-800';
      case 'Completed':
        return 'bg-green-100 text-green-800';
      case 'Delivered':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/admin/dashboard')}
              className="text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">Order Management</h1>
          </div>
          <button
            onClick={loadOrders}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            <RefreshCw className="w-5 h-5" />
            <span className="font-medium">Refresh</span>
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {orders.length === 0 ? (
          <div className="bg-white rounded-xl shadow-md p-12 text-center">
            <p className="text-gray-500 text-lg mb-2">No orders yet</p>
            <p className="text-gray-400">Orders will appear here when customers place them</p>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map((order) => (
              <div key={order.id} className="bg-white rounded-xl shadow-md p-6">
                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <img
                      src={order.reference_image_url}
                      alt="Reference"
                      className="w-full h-48 object-cover rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                      onClick={() => setSelectedImage(order.reference_image_url)}
                    />
                  </div>

                  <div className="md:col-span-2 space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-1">
                          {order.customer_name}
                        </h3>
                        <p className="text-gray-600">{order.customer_phone}</p>
                      </div>
                      <div className="flex gap-2">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(order.order_status)}`}>
                          {order.order_status}
                        </span>
                        <button
                          onClick={() => handleDelete(order.id, order.reference_image_url)}
                          className={`p-2 rounded-lg transition-colors ${
                            deleteConfirm === order.id
                              ? 'bg-red-100 text-red-600'
                              : 'text-gray-400 hover:bg-red-50 hover:text-red-600'
                          }`}
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Order Type:</span>
                        <p className="font-semibold text-gray-900">{order.artwork_type}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Order Date:</span>
                        <p className="font-semibold text-gray-900">
                          {new Date(order.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>

                    {order.special_instructions && (
                      <div>
                        <span className="text-sm text-gray-600">Instructions:</span>
                        <p className="text-gray-900 mt-1">{order.special_instructions}</p>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                      <div className="flex items-center gap-4">
                        <div>
                          <span className="text-sm text-gray-600">Amount:</span>
                          <p className="text-2xl font-bold text-amber-600">₹{order.amount}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                            order.payment_status === 'paid'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {order.payment_status.toUpperCase()}
                          </span>
                          <select
                            value={order.payment_method}
                            onChange={(e) => updatePaymentMethod(order.id, e.target.value)}
                            className="px-3 py-1 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                          >
                            {paymentMethods.map((method) => (
                              <option key={method} value={method}>
                                {method}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => updateOrderStatus(order.id, order.order_status)}
                          className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
                        >
                          Update Status
                        </button>
                        {order.payment_status === 'pending' && (
                          <button
                            onClick={() => updatePaymentStatus(order.id)}
                            className="px-4 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors"
                          >
                            Mark as Paid
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {selectedImage && (
        <div
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute -top-12 right-0 bg-white/10 backdrop-blur-sm text-white p-2 rounded-full hover:bg-white/20 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={selectedImage}
              alt="Full size"
              className="max-w-full max-h-[90vh] object-contain rounded-lg"
            />
          </div>
        </div>
      )}
    </div>
  );
};
