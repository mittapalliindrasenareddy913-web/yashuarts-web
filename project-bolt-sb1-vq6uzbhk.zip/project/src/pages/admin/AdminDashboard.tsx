import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, Plus, CreditCard as Edit, Trash2, Shield, ShoppingBag } from 'lucide-react';
import { supabase, Artwork } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { LoadingSpinner } from '../../components/LoadingSpinner';

export const AdminDashboard = () => {
  const [artworks, setArtworks] = useState<Artwork[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const { signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    loadArtworks();
  }, []);

  const loadArtworks = async () => {
    const { data } = await supabase
      .from('artworks')
      .select('*')
      .order('created_at', { ascending: false });

    setArtworks(data || []);
    setLoading(false);
  };

  const handleDelete = async (id: string, imageUrl: string) => {
    if (deleteConfirm !== id) {
      setDeleteConfirm(id);
      setTimeout(() => setDeleteConfirm(null), 3000);
      return;
    }

    try {
      const fileName = imageUrl.split('/').pop();
      if (fileName) {
        await supabase.storage.from('artworks').remove([fileName]);
      }
    } catch (error) {
      console.error('Error deleting image:', error);
    }

    await supabase.from('artworks').delete().eq('id', id);
    setDeleteConfirm(null);
    loadArtworks();
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/admin');
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-gray-900" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Studio Admin</h1>
              <p className="text-sm text-gray-600">Manage Artworks & Orders</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Total Artworks</h3>
            <p className="text-4xl font-bold text-amber-600">{artworks.length}</p>
          </div>
          <button
            onClick={() => navigate('/admin/orders')}
            className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl shadow-md p-6 hover:from-blue-600 hover:to-blue-700 transition-all text-left"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold mb-2">View Orders</h3>
                <p className="text-blue-100">Manage customer orders</p>
              </div>
              <ShoppingBag className="w-12 h-12 text-white/80" />
            </div>
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Artwork Library</h2>
            <button
              onClick={() => navigate('/admin/artwork/new')}
              className="flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-amber-600 hover:to-orange-700 transition-all shadow-md"
            >
              <Plus className="w-5 h-5" />
              New Artwork
            </button>
          </div>

          {artworks.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">No artworks yet</p>
              <button
                onClick={() => navigate('/admin/artwork/new')}
                className="text-amber-600 hover:text-amber-700 font-semibold"
              >
                Add Your First Piece
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {artworks.map((artwork) => (
                <div
                  key={artwork.id}
                  className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:border-amber-300 hover:bg-amber-50/50 transition-all"
                >
                  <img
                    src={artwork.image_url}
                    alt={artwork.title}
                    className="w-20 h-20 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{artwork.title}</h3>
                    <div className="flex items-center gap-4 mt-1">
                      <span className="text-sm text-gray-600">{artwork.category}</span>
                      <span className="text-sm font-semibold text-amber-600">₹{artwork.price}</span>
                      {artwork.is_featured && (
                        <span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded-full font-medium">
                          Featured
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate(`/admin/artwork/edit/${artwork.id}`)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(artwork.id, artwork.image_url)}
                      className={`p-2 rounded-lg transition-colors ${
                        deleteConfirm === artwork.id
                          ? 'bg-red-100 text-red-600'
                          : 'text-gray-600 hover:bg-red-50 hover:text-red-600'
                      }`}
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
