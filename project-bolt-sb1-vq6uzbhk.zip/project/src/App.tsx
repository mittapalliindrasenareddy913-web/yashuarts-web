import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';

import { LoginScreen } from './pages/LoginScreen';
import { SignupScreen } from './pages/SignupScreen';
import { HomeScreen } from './pages/HomeScreen';
import { GalleryScreen } from './pages/GalleryScreen';
import { ArtworkDetailScreen } from './pages/ArtworkDetailScreen';
import { ChatScreen } from './pages/ChatScreen';
import { CustomOrderScreen } from './pages/CustomOrderScreen';
import { PaymentScreen } from './pages/PaymentScreen';
import { UserProfileScreen } from './pages/UserProfileScreen';
import { ArtistProfileScreen } from './pages/ArtistProfileScreen';

import { AdminLoginScreen } from './pages/admin/AdminLoginScreen';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { AddEditArtworkScreen } from './pages/admin/AddEditArtworkScreen';
import { OrdersScreen } from './pages/admin/OrdersScreen';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginScreen />} />
          <Route path="/signup" element={<SignupScreen />} />

          <Route path="/" element={<ProtectedRoute><HomeScreen /></ProtectedRoute>} />
          <Route path="/gallery" element={<ProtectedRoute><GalleryScreen /></ProtectedRoute>} />
          <Route path="/artwork/:id" element={<ProtectedRoute><ArtworkDetailScreen /></ProtectedRoute>} />
          <Route path="/chat" element={<ProtectedRoute><ChatScreen /></ProtectedRoute>} />
          <Route path="/custom-order" element={<ProtectedRoute><CustomOrderScreen /></ProtectedRoute>} />
          <Route path="/payment" element={<ProtectedRoute><PaymentScreen /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><UserProfileScreen /></ProtectedRoute>} />
          <Route path="/artist" element={<ProtectedRoute><ArtistProfileScreen /></ProtectedRoute>} />

          <Route path="/admin" element={<AdminLoginScreen />} />
          <Route path="/admin/dashboard" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
          <Route path="/admin/artwork/:id" element={<ProtectedRoute><AddEditArtworkScreen /></ProtectedRoute>} />
          <Route path="/admin/orders" element={<ProtectedRoute><OrdersScreen /></ProtectedRoute>} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
