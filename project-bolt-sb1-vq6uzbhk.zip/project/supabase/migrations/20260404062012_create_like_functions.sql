/*
  # Add Like Helper Functions

  ## Overview
  Create database functions to increment and decrement artwork likes count.

  ## Functions
  - `increment_likes(artwork_id uuid)` - Increments likes_count for an artwork
  - `decrement_likes(artwork_id uuid)` - Decrements likes_count for an artwork
*/

CREATE OR REPLACE FUNCTION increment_likes(artwork_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE artworks
  SET likes_count = likes_count + 1
  WHERE id = artwork_id;
END;
$$;

CREATE OR REPLACE FUNCTION decrement_likes(artwork_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE artworks
  SET likes_count = GREATEST(0, likes_count - 1)
  WHERE id = artwork_id;
END;
$$;
