/*
  # Storage Policies for YashuArts

  ## Overview
  Set up storage policies for artworks, orders, and avatars buckets.

  ## Security
  - Public read access for all authenticated users
  - Authenticated users can upload and manage images
  - Proper access controls for each bucket type
*/

-- Storage policies for artworks bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Anyone can view artwork images'
  ) THEN
    CREATE POLICY "Anyone can view artwork images"
      ON storage.objects FOR SELECT
      TO authenticated
      USING (bucket_id = 'artworks');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Authenticated users can upload artwork images'
  ) THEN
    CREATE POLICY "Authenticated users can upload artwork images"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (bucket_id = 'artworks');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Authenticated users can update artwork images'
  ) THEN
    CREATE POLICY "Authenticated users can update artwork images"
      ON storage.objects FOR UPDATE
      TO authenticated
      USING (bucket_id = 'artworks')
      WITH CHECK (bucket_id = 'artworks');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Authenticated users can delete artwork images'
  ) THEN
    CREATE POLICY "Authenticated users can delete artwork images"
      ON storage.objects FOR DELETE
      TO authenticated
      USING (bucket_id = 'artworks');
  END IF;
END $$;

-- Storage policies for orders bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Users can view order images'
  ) THEN
    CREATE POLICY "Users can view order images"
      ON storage.objects FOR SELECT
      TO authenticated
      USING (bucket_id = 'orders');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Users can upload order images'
  ) THEN
    CREATE POLICY "Users can upload order images"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (bucket_id = 'orders');
  END IF;
END $$;

-- Storage policies for avatars bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Anyone can view avatars'
  ) THEN
    CREATE POLICY "Anyone can view avatars"
      ON storage.objects FOR SELECT
      TO authenticated
      USING (bucket_id = 'avatars');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Users can upload own avatar'
  ) THEN
    CREATE POLICY "Users can upload own avatar"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (bucket_id = 'avatars');
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'objects' 
    AND policyname = 'Users can update own avatar'
  ) THEN
    CREATE POLICY "Users can update own avatar"
      ON storage.objects FOR UPDATE
      TO authenticated
      USING (bucket_id = 'avatars')
      WITH CHECK (bucket_id = 'avatars');
  END IF;
END $$;