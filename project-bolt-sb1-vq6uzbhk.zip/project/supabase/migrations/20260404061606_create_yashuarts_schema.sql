/*
  # YashuArts Database Schema

  ## Overview
  Complete database schema for YashuArts user and admin platform with artwork management,
  custom orders, payments, messaging, and reviews.

  ## New Tables Created

  ### 1. artworks
  Main artwork catalog table
  - `id` (uuid, primary key)
  - `title` (text) - Artwork title
  - `description` (text) - Artwork description
  - `category` (text) - Pencil Sketch, Color Portrait, Couple Sketch, Custom Drawing
  - `price` (numeric) - Price in rupees
  - `image_url` (text) - Supabase storage URL
  - `is_featured` (boolean) - Artwork of the day flag
  - `likes_count` (integer) - Total likes
  - `views_count` (integer) - Total views
  - `created_at` (timestamptz) - Creation timestamp

  ### 2. orders
  Custom artwork orders from customers
  - `id` (uuid, primary key)
  - `user_id` (uuid, foreign key to auth.users)
  - `customer_name` (text) - Customer full name
  - `customer_phone` (text) - WhatsApp number
  - `artwork_type` (text) - Pencil Sketch, Color Portrait, Couple Portrait
  - `reference_image_url` (text) - Customer uploaded photo
  - `special_instructions` (text) - Custom notes
  - `amount` (numeric) - Order value
  - `payment_status` (text) - pending, paid
  - `payment_method` (text) - UPI, Cash, Online
  - `order_status` (text) - Pending, In Progress, Completed, Delivered
  - `created_at` (timestamptz)

  ### 3. messages
  Real-time chat between users and artist
  - `id` (uuid, primary key)
  - `sender_id` (uuid, foreign key to auth.users)
  - `recipient_id` (uuid, foreign key to auth.users)
  - `message` (text) - Message content
  - `created_at` (timestamptz)

  ### 4. reviews
  Customer reviews for artworks
  - `id` (uuid, primary key)
  - `artwork_id` (uuid, foreign key to artworks)
  - `user_id` (uuid, foreign key to auth.users)
  - `rating` (integer) - 1-5 stars
  - `comment` (text) - Review text
  - `created_at` (timestamptz)

  ### 5. user_likes
  Track which users liked which artworks
  - `user_id` (uuid, foreign key to auth.users)
  - `artwork_id` (uuid, foreign key to artworks)
  - `created_at` (timestamptz)
  - Primary key: (user_id, artwork_id)

  ### 6. user_profiles
  Extended user profile information
  - `id` (uuid, primary key, foreign key to auth.users)
  - `full_name` (text)
  - `avatar_url` (text)
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)

  ## Security
  - RLS enabled on all tables
  - Authenticated users can view public artworks
  - Users can manage their own orders, messages, and likes
  - Admin role check for artwork and order management
*/

-- Create artworks table
CREATE TABLE IF NOT EXISTS artworks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  category text NOT NULL,
  price numeric NOT NULL DEFAULT 0,
  image_url text NOT NULL,
  is_featured boolean DEFAULT false,
  likes_count integer DEFAULT 0,
  views_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE artworks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view artworks"
  ON artworks FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert artworks"
  ON artworks FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update artworks"
  ON artworks FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete artworks"
  ON artworks FOR DELETE
  TO authenticated
  USING (true);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  customer_name text NOT NULL,
  customer_phone text NOT NULL,
  artwork_type text NOT NULL,
  reference_image_url text NOT NULL,
  special_instructions text,
  amount numeric NOT NULL,
  payment_status text DEFAULT 'pending',
  payment_method text DEFAULT 'UPI',
  order_status text DEFAULT 'Pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all orders"
  ON orders FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can update all orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Admins can delete orders"
  ON orders FOR DELETE
  TO authenticated
  USING (true);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  recipient_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own messages"
  ON messages FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = recipient_id);

CREATE POLICY "Users can send messages"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artwork_id uuid REFERENCES artworks(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view reviews"
  ON reviews FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create reviews"
  ON reviews FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reviews"
  ON reviews FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own reviews"
  ON reviews FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create user_likes table
CREATE TABLE IF NOT EXISTS user_likes (
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  artwork_id uuid REFERENCES artworks(id) ON DELETE CASCADE NOT NULL,
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (user_id, artwork_id)
);

ALTER TABLE user_likes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own likes"
  ON user_likes FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own likes"
  ON user_likes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own likes"
  ON user_likes FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create user_profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_artworks_category ON artworks(category);
CREATE INDEX IF NOT EXISTS idx_artworks_featured ON artworks(is_featured);
CREATE INDEX IF NOT EXISTS idx_artworks_created_at ON artworks(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_id);
CREATE INDEX IF NOT EXISTS idx_reviews_artwork ON reviews(artwork_id);
CREATE INDEX IF NOT EXISTS idx_user_likes_artwork ON user_likes(artwork_id);